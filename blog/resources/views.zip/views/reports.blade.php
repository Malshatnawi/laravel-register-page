<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>Reports</title>
  </head>
  <body>
  <div class="collapse" id="navbarToggleExternalContent">
  <div class="bg-dark p-4">
    <h5 class="text-white h4">Collapsed content</h5>
    <span class="text-muted">Toggleable via the navbar brand.</span>
  </div>
</div>
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>

<table class="table table-bordered border-primary">
<tr>
    <th>Name</th>
    <th>Attended Days</th>
    <th>Submited Projects</th>
  </tr>
  @foreach($students as $key => $value)
  <tr>
    <td>{{$value['name']}}</td>
    <td>{{count($value['attendance'])}}</td>
    <td>{{count($value['projects'])}}</td>
  </tr>

  @endforeach
  
  
</table>


<table class="table table-bordered border-primary">
<tr>
    <th>Name</th>
    <th>Day 1 Check_in</th>
    <th>Day 1 Check_out</th>
    <th>Day 1 hours</th>
    <th>Day 2 Check_in</th>
    <th>Day 2 Check_out</th>
    <th>Day 2 hours</th>
    <th>Day 3 Check_in</th>
    <th>Day 3 Check_out</th>
    <th>Day 3 hours</th>  </tr>
  @foreach($students as $key => $value)
  <tr>
    <td>{{$value['name']}}</td>
    @foreach ($value['attendance'] as $key1 => $value1)
    <td>{{$value1['check_in']}}</td>
    <td>{{$value1['check_out']}}</td>
    <?php 

    if($value1['check_out'] - $value1['check_in'] >0){
        echo "<td>"."{$value1['check_out']} - {$value1['check_in']}"."</td>";
    }

?>
    <!-- <td>{{$value1['check_in']}}</td>
    <td>{{$value1['check_out']}}</td>
    <td>{{$value1['check_in']}}</td>
    <td>{{$value1['check_out']}}</td> -->
  
  @endforeach
  </tr>



  @endforeach
  
  
</table>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
  </body>
</html>